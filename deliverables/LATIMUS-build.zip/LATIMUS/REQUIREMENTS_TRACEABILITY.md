# LATIMUS requirements to evidence

Checkpoint: October 24, 2026 (America/Chicago), integrated alpha 0.1.0.

The controlling scope remains `source-spec/LATIMUS_PRODUCT_DIRECTIVE.md` and its original PDF appendices. A tile, registry row, operator checkbox or fixture is not complete implementation or live proof. `TESTED_FIXTURE` applies only to the behavior named in that row. The full roadmap remains open.

Status meanings: `TESTED_FIXTURE` = exercised by unit/integration fixtures; `CODED_UNTESTED` = implemented without acceptance evidence at this checkpoint; `IN_PROGRESS` = partial workflow; `NOT_STARTED` = required work absent; `REQUIRES_QUALIFIED_HUMAN` = professional execution boundary. Final observed browser/package results are recorded in `docs/ACCEPTANCE.md`; direct file/extension and cross-OS targets remain unverified.

| Requirement / directive section | Status | Implementation | Observed evidence | Remaining gap |
|---|---|---|---|---|
| R01 Product identity and separation, §§1–3 | IN_PROGRESS | Product docs, names, isolated checkout; no FORWARD imports/runtime | Repository inspection | Full business operating scope remains incomplete |
| R02 Original 15 modules, §7 | TESTED_FIXTURE | `src/domain/capabilities.ts` M01–M15 partial/planned descriptors | Coverage test checks 15 unique modules | Registry entries are not executable full modules |
| R03 Original 152 role functions / 360 reference positions, §2 / Appendix A | TESTED_FIXTURE | `ROLE_COVERAGE`, `docs/original-coverage-ledger.md` | Exact count and reference sum checked | Every full original role responsibility remains `not implemented`; supporting tools do not implement a profession |
| R04 Original 67 services, §2 / Appendix B | TESTED_FIXTURE | `SERVICE_COVERAGE`, preserved original text | Exact count and valid module links checked | Each full original service remains `not implemented`; build practical workflows and evidence |
| R05 No mandatory runtime server, §4 | CODED_UNTESTED | Bundled shared entry point, no backend imports or network bridge | Source inspection | Exercise actual generated distributions |
| R06 Manifest V3 distribution, §4.1 | CODED_UNTESTED | `scripts/build.mjs`, `extension-worker.js` | Source inspection only at this checkpoint | Actual toolbar, lifecycle, permission and offline browser checks |
| R07 Portable self-contained HTML, §4.2 | CODED_UNTESTED | Bundled inline assets and hash CSP | Source inspection only | Open actual file artifact, test CSP/Web Crypto and explicit save/load |
| R08 Three AI modes, §5 | IN_PROGRESS | Local tools and bounded manual task-packet export in Reports | Domain tools fixture-tested; handoff UI acceptance pending | No browser-local inference, connected provider or response-import workflow |
| R09 Executive orchestrator / executor / independent reviewer, §6 | NOT_STARTED | Planned registry boundaries | None | Actual capability contracts, bounded execution, independent review routing/evaluations |
| R10 Tool Broker / deterministic policy, §§6,26 | TESTED_FIXTURE | `workspace.ts` explicit action switch, strict validation | Unsupported actions rejected; exact-content approval tests | Broader permissions/standing policies and material-commitment workflows |
| R11 Shared Intelligence Fabric, §§8–10 | IN_PROGRESS | Source-family/trigger taxonomy; company/signal/evidence/EOS models | Ingestion and routing fixture tests | Full source-specific detection and all end-to-end scenarios |
| R12 Market attractiveness engine, §8.1 | NOT_STARTED | No economic baseline/ranking engine | None | Census/BLS ingestion, source-backed metrics, geography/industry research ranking; do not confuse company EOS with market ranking |
| R13 Source registry, §11 | IN_PROGRESS | Manual/import source records, modes, tiers, limitations and import timestamps | Source import status fixture-tested | Live retrieval, terms checks, complete source metadata, real health/cadence checks |
| R14 All source families, §§9,11 | IN_PROGRESS | Eight-family taxonomy and generic manual intake | Schema/import tests | Family-specific adapters and approved live/dataset tests; no fabricated connection status |
| R15 Evidence/provenance, §12 | TESTED_FIXTURE | Separate event/publication/discovery/import dates, reference, excerpt, tier, review, SHA-256 | Evidence dedup, wrong-tier/failed/stale/future/contradiction gate tests | Independent source authentication, richer confidence/claim conflicts and full lineage exports |
| R16 Company identity / signal fingerprint, §§13–14 | TESTED_FIXTURE | Exact normalized names/aliases, domain conflict rejection, event fingerprint | Four sources → one company/signal + four evidence records; repeated import idempotent | Human merge queue, subsidiary/identifier reconciliation, richer confidence logic |
| R17 100-point versioned EOS and bands, §15 | TESTED_FIXTURE | Bounded 30/25/20/15/10 integer components, `eos-1.0.0` | Maxima/boundary/invalid input tests | Score history, approved overrides and formula-change evaluation |
| R18 POC enrichment and weak-evidence gates, §§12,15 | TESTED_FIXTURE | EOS 65+, human-verified current A/B or two different-host C sources; Tier D blocked | EOS64, Tier D100, stale, unreviewed and failed-source tests | Research executor, owner overrides, configurable evidence policy and source-independence review |
| R19 Outcome-owner mapping and contact states, §§13,16 | IN_PROGRESS | Sector/trigger role rationale; separate user-provided/unverified/public/unavailable states | Policy validates eligible contact state and account link | Configurable company/ownership/geography rules; actual public POC verification and evidence freshness |
| R20 Cadence and honest paused operation, §17 | IN_PROGRESS | Sources show manual cadence; jobs execute only open/unlocked | Local report restart fixture | General due-on-resume/awaiting-unlock scheduler, sleep/device fault acceptance |
| R21 Durable work engine, §§6,25 | IN_PROGRESS | Persisted local report jobs, attempts, status, artifact idempotency | Restart representation + one artifact receipt fixture | General dependencies, deadlines, backoff, checkpoints, leases, cancellation/recovery semantics, outbox reconciliation |
| R22 Approval controls, §26 | TESTED_FIXTURE | Exact content/destination hash, policy version, expiry, reviewer, suppression | Modified content, duplicate draft, cross-account, suppression and unsupported action tests | No standing permissions or external executor; no external receipt may be claimed |
| R23 CRM/outbound, §29 | IN_PROGRESS | Contact dedup, opt-out suppression, safe drafts, unresolved merge fields rejected | Policy fixture tests | Lawful marketing settings, send caps/provider limits, receipts and unsubscribe processing before live outbound |
| R24 Commercial lifecycle, §27 | IN_PROGRESS | Qualification, CRM stages/outcome notes, won-only engagement intake | Won-evidence guard fixture | Discovery, Blueprint, WBS/effort, proposal/SOW/agreement, terms, invoices/collections, renewals |
| R25 Pricing engine, §28 | TESTED_FIXTURE | Exact cent-based user rates/hours/direct cost, contingency, margin, floor flag and separate markup | Nine finance tests include pricing math, floor, rounding, overflow | Approval exception workflow and persisted approved scope/rate source links |
| R26 PMO/delivery, §§7,27 | IN_PROGRESS | Engagement intake, task/risk/decision/milestone records, owners, due dates, status, expected benefit | Workspace validation and actual engagement/PMO browser flows passed | Resource/dependency planning, acceptance, changes, actual realized benefits, handover/closeout |
| R27 Client finance, M05 | IN_PROGRESS | User-linked cash forecast and pricing workpapers | Deterministic cash/negative liquidity tests | Reconciliation, statements, working capital, budgets/FP&A, source ledger, payroll/tax/lender packages |
| R28 Construction, M06 | TESTED_FIXTURE | Budget/change/actual/remaining EAC and variance tool | Explicit EAC/variance fixture | WIP, commitments, schedules, procurement, pay apps, inspection/HSE/closeout |
| R29 Real estate, M07 | TESTED_FIXTURE | Annual effective income, NOI and cap-rate calculation | Vacancy and zero-denominator fixture | Property registry, sensitivity/returns, rent import, transaction/operations workflows |
| R30 Technology, M08 | IN_PROGRESS | Generic PMO records can track technology work; module explicitly partial | No technology-specific acceptance | IT inventory, requirements, migration/integration/test/adoption/rollback workflows |
| R31 Logistics, M09 | TESTED_FIXTURE | User-input fleet cost/profit and cost per mile | No-mile denominator and explicit-cost fixture | Routes/network, freight audit, inventory, suppliers, TMS/WMS and live FMCSA |
| R32 Energy, M10 | TESTED_FIXTURE | Net annual savings/simple-payback calculation | No-positive-payback fixture | Tariffs, interconnection, permits, vendors, capex finance sensitivity and performance |
| R33 M&A, M11 | TESTED_FIXTURE | Explicit EBITDA-multiple enterprise/equity value tool | EV/debt/cash arithmetic fixture | Diligence, normalization, data room, Day1/100day integration, synergies/realized value |
| R34 Owner/family enterprise, M12 | NOT_STARTED | Module truthfully planned | None | Separate personal books, net worth, governance/succession/advisor workflows |
| R35 Corporate services, M14 | IN_PROGRESS | Approval/audit/suppression foundations | Owner-control fixtures | Billing/treasury/AP/payroll, legal/people/vendors/procurement/licenses/compliance workflows |
| R36 Independent assurance, M15 | IN_PROGRESS | Deterministic gates, artifact review flag and separate code review | Security fixtures and `harness/code_review/initial-release.md` | True independent runtime reviewer, acceptance scope, professional/quality evaluations |
| R37 Connectors, §30 | NOT_STARTED | Explicit unavailable states and manual exchange only | No live connection test; none claimed | Approved direct provider authentication, actual browser-compatible integration and evidence |
| R38 Browser security, §31 | IN_PROGRESS | Safe React text rendering, no eval/message/fetch bridge, bundled code, restrictive CSP | Input validation and unsupported-action tests | Built artifact CSP/injection/extension tests and full threat-model acceptance |
| R39 Encrypted workspace, §32 | TESTED_FIXTURE | PBKDF2-SHA256, AES-256-GCM, random IV/salt, nonextractable live key | Roundtrip, wrong passphrase, altered ciphertext, invalid KDF/version tests | Browser lifecycle/quota/idle checks; migration beyond schema1; security audit |
| R40 Backup/device handoff, §33 | IN_PROGRESS | Encrypted manifest-like workspace record bundle, link validation, preview/replacement, previous backup | Schema/link/ciphertext fixture tests | Actual built file roundtrip and cross-OS tests, attachment support and detailed merge/conflict preview |
| R41 Executive UX and reporting, §§34–35 | IN_PROGRESS | Command Center, intelligence, CRM, PMO, finance, reports, approvals, sources, capabilities, settings | Deterministic report artifact fixture | Complete navigation breadth and audience-adaptive reports/maps/briefs; browser usability acceptance |
| R42 Learning and management intelligence, §36 | NOT_STARTED | Raw local record counts and outcomes are available | No learning acceptance | Source yield, attribution, conversion timelines, watchlists/content, approved scoring governance |
| R43 Required end-to-end scenarios, §37 | IN_PROGRESS | Selected domain fixtures for dedup, weak evidence, restart, control and arithmetic | 33 core/contract tests; seven distinct browser workflows passed; details in docs/ACCEPTANCE.md | Execute all25 listed scenarios with recorded outcomes; do not extrapolate from subset |
| R44 Re-baseline and phase process, §38 | IN_PROGRESS | `harness/context/phase-00.md`, decision and state files | Empty repository observation; preservation ledger | Full phase exits not declared; dependency-spanning alpha sequencing recorded in D08 |
| R45 Verification/distribution deliverables, §§39–40 | IN_PROGRESS | Source, schemas, tests and build script | Unit/typecheck evidence only at this checkpoint | Actual packages/browser/OS/workload/device matrix, full coverage and release acceptance |
| R46 Definition of done, §41 | IN_PROGRESS | Useful bounded local alpha | Evidence above | Full directive is not complete; see `BUILD_STATE.md` and `NEXT_ACTIONS.md` |
| R48 Intelligence-to-BD pipeline, §18 | IN_PROGRESS | Qualified opportunities enter CRM; raw imported signals remain separate | EOS/evidence gates and opportunity fixtures | Full market-to-revenue chain, CRM export, discovery/Blueprint/billing/learning |
| R49 Executive Opportunity Brief, §19 | IN_PROGRESS | Deterministic executive report includes company, need hypothesis, role, EOS, gate and source excerpts | Report generation/restart fixture | Dedicated complete opportunity brief with why-now, fact/inference, consequences, service fit, offer/outreach angle and next action |
| R50 Intelligence-driven marketing, §20 | NOT_STARTED | No automatic publishing | None | Source-backed content briefs, confidentiality controls and human publication authorization |
| R51 Runtime capability contract, §21 | IN_PROGRESS | Stable module IDs, version, purpose, inputs/outputs, evidence, permissions and quality/escalation descriptors | Registry coverage/count tests | Executable per-skill steps, triggers, permitted tools, calculation methods, schemas, role/service mappings, cost classes and evaluations |
| R52 Complete data architecture, §22 | IN_PROGRESS | Linked source/company/signal/opportunity/contact/engagement/task/approval/audit/job/artifact records within one workspace | Strict schema and cross-link fixtures | Remaining entity types, firm/client/personal separation, attachment/blob model and scoped queries across all future tools |
| R53 Provenance classifications, §23 | IN_PROGRESS | Source timestamps/reference/excerpt/hash; need labeled hypothesis; calculation workpapers include input references | Evidence and finance fixtures | Full observed/user-provided/calculated/inferred/estimated/unknown taxonomy and period/unit/currency/page-cell provenance, immutable attachments |
| R54 Scoped local search and knowledge, §24 | IN_PROGRESS | Local string filtering of company/signal/opportunity records in current workspace | UI browser acceptance pending | Full-text client/account-scoped retrieval, knowledge collections, source/artifact distinctions and optional evaluated embeddings |
| R47 Qualified professional execution | REQUIRES_QUALIFIED_HUMAN | Visible calculation/workflow scope disclaimers and no external execution | Code review | Legal, tax, securities, engineering, filings, fund movements, certification and material contracts require qualified human decision/execution |

## Original responsibility ledger

The original source appendix and exact names are preserved in `docs/original-coverage-ledger.md`. Machine-readable `ROLE_COVERAGE` has 152 individually identified rows (`ROLE-001`–`ROLE-152`), totaling360 reference positions; `SERVICE_COVERAGE` has67 individually identified rows (`SERVICE-001`–`SERVICE-067`). Each row retains its original module routing and status `not implemented`. Update a row only after a practical workflow and its evidence cover that full responsibility; module partial tools do not justify blanket completion.

## Source-specific authority

Manual/imported sample sources are opt-in fictional fixtures, labeled in the UI and generated briefs. No official dataset, real company event, POC verification, fresh retrieval, paid provider, live send or professional credential is established by these records. Complete separation and original scope remain requirements even when absent from the current UI.

## Source-scope clarification and 0.2 evidence

The owner's explicit21-row source list is the controlling acceptance checklist for sourcing. Real-estate data is temporarily deferred by the owner; two property-specific triggers are deferred and19 remain active, with the private deed-of-trust component of refinancing also deferred. SEC refinancing remains required. See docs/TRIGGER_SOURCE_ACCEPTANCE.md for row-by-row status.

`src/domain/connectors.ts`, `src/platform/sources.ts`, SourcesPanel and source-run actions implement three bounded direct request pipelines. Tests cover fixed URL/filter construction, raw field semantics, zero/error/schema/size handling, encrypted receipts, stale-query rejection and additive old-vault compatibility. Browser fixtures test actual fetch→parse→persist→render, not official live endpoints. Full source-backed trigger detection and remaining source adapters are **not implemented**. No row is upgraded to live-tested or fully covered from these pipeline fixtures.

## Re-administration requirements baseline

Authority: MASTER_READMINISTRATION_PROMPT.md; supplied55-source plan and translated enrichment behavior. Existing evidence retained above. New coverage is not asserted before execution.

| ID | Required behavior | Baseline before expansion | Evidence target |
|---|---|---|---|
| RA01 | CSV-first raw import/mapping/all-column preservation | NOT BUILT | parser/export fidelity, duplicate hash, browser import/mapping |
| RA02 | Company-first research/cache/resolution | NOT BUILT | grouping/cache reuse, ambiguity, approved extension crawl |
| RA03 | Public evidence/contact confidence/generic separation | NOT BUILT | observed-only matching, false-positive fixtures, evidence review |
| RA04 | Durable prospect jobs/pause/resume/cancel/retry | NOT BUILT | encrypted checkpoints, interruption/cancel/provider-failure tests |
| RA05 |55 source master metadata/deployment/health | PARTIAL existing5adapters | exact 55rows, truthful support state, representative source/import |
| RA06 | Shared spine/distinct csv_prospect vs intelligence_signal | PARTIAL sharedrecords | migration, sharedCompany360, no silent intake blending |
| RA07 | Explicit CRM/outreach promotion; CSV noEOSgate | PARTIAL existingapprovalpolicy | selected review, dedup/suppression, provenance and approval fixtures |
| RA08 | Three independent scoring systems | PARTIAL EOSonly | separate Permit Score/EOS/ContactConfidence contracts/tests |
| RA09 | Advanced/Portable capability truth and secret boundary | PARTIAL modes/vault | strict worker messages, encrypted secret import, mode errors |
| RA10 |100/1,000/10,000row benchmark/paged UI | NOT BUILT | measured parse/normalize/group/export/commit timing and counts |
| RA11 | Independent re-administration review | NOT RUN | reviewer findings/disposition, regression verification |


## Re-administration verified result (0.4.0)

Historical baseline above is retained. Actual acceptance and pending runtime boundaries: docs/READMINISTRATION_ACCEPTANCE.md.

| ID | Current state | Implementation / executed evidence |
|---|---|---|
| RA01 | Implemented | prospecting.ts, csvBridge/csv-worker, ProspectingPanel; original/duplicate headers, mappings, encoding, hashes, browser full export/reload |
| RA02 | Implemented; installed/live provider acceptance pending | publicResearch, prospectBroker, prospectRunner; grouping/cache/ambiguity/public transport and scoped private provider fixtures |
| RA03 | Implemented | prospectPolicy consistency at checkpoint/restore/promotion;23integration,22domain tests plus exact source URL/robots tests |
| RA04 | Implemented for open/unlocked full-tab | prospectActions/Runner/main;11runner,9lineage cases, real encrypted browser processing/reload; no closed-browser promise |
| RA05 |55 registry +47 enabled manual intake; partial native adapters | sourceMaster/sourceCsv/SourceMasterPanel;55metadata tested, owner-disabled INT-015–022 enforced, raw receipts preserved. Only3plan entries map to partial native adapters |
| RA06 | Implemented | Company origins, shared Source/Evidence, reciprocal Contact/row references; cross-system integration and browser isolation |
| RA07 | Implemented local handoff | accepted review/promote; dedup/suppression; CSV-specific EOS exception, existing human exact-content approvals; no sender |
| RA08 | Implemented separate score contracts | optional supplied Permit Lead Score with conflicting-score rejection; EOS30/25/20/15/10 and A1/A2/B1/B2/C; separately reconciled Contact Confidence |
| RA09 | Implemented; managed runtime acceptance pending | TS MV3 broker, embedded/self CSV workers, exact sender/job/row/settings checks, encrypted provider handle import, public A/AAAA/robots/size budgets; no real Brave test |
| RA10 | Measured | docs/prospecting-*-benchmark.json +browser-prospecting-10000-benchmark.json; CPU/crypto100/1000/10,000 repeated/unique and real Chromium10,000 local persistence/export; device/live throughput not measured |
| RA11 | Reviewed, reproduced findings fixed | three independent reports with final dispositions,161 core tests +16 browserpassed/2 managedskips |
